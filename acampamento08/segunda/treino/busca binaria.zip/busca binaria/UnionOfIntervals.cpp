// Includes {{{
#include <algorithm>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <queue>
#include <set>
#include <map>
#include <cstdio>
#include <cstdlib>
#include <cctype>
#include <cmath>
#include <stdio.h>
using namespace std;
// }}}

#define TRACE(x...) x
#define PRINT(x...) TRACE(printf (x))
#define WATCH(x) TRACE(cout << #x << ": " << x << endl)
//#define DEBUG

// Classe e Testes - UnionOfIntervals {{{
class UnionOfIntervals
{
public: 
int nthElement(vector <int> lowerBound, vector <int> upperBound, int n); 
 
}; 
// }}}

int UnionOfIntervals::nthElement(vector <int> lowerBound, vector <int> upperBound, int n) 
{
}

// Fun��o main {{{
// }}}


// Powered by FileEdit
// Powered by TZTester 1.01 [25-Feb-2003]
// Powered by CodeProcessor
